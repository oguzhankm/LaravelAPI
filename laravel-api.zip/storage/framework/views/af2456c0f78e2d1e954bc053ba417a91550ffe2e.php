
<h1><?php echo e($name); ?></h1>
Product ID: <?php echo e($id); ?>, Type: <?php echo e($type); ?>


<div>
    <?php if($id == 1): ?>
        1 No'lu ürün gösterilmektedir.
    <?php elseif($id == 2): ?>
        2 no'lu ürün gösterilmektedir.
    <?php else: ?>
        Diğer ürün gösterilmektedir.
    <?php endif; ?>
</div>

<div>
    <?php for($i = 0; $i<10; $i++): ?>
       Döngü değeri <?php echo e($i); ?><br>
    <?php endfor; ?>
</div>
<div>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($categorie); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\LaravelAPI\laravel-api\resources\views/Product.blade.php ENDPATH**/ ?>